const mongoose =require('mongoose');
const Schema = mongoose.Schema;


const studentSchema = new Schema({
    fullname:{

        type:String,
        required:true,
        trim:true  // removing the first space in value input 

    },
    
    email:{

        type:String,
        required:true,
        trim:true  // removing the first space in value input     

    }



},{timestamps:true})// date  and time of the data being passed
    
   


const Student= mongoose.model('student',studentSchema);

module.exports = Student;

