const router = require('express').Router();
let Student = require('../models/student.model');




//home
router.route('/').get((req,res)=>{

    Student.find() // PROMISE IF ELSE 
        .then(student => res.json(student)) // IF TRUE CHECK
        .catch(err =>res.status(400).json('Error : '+ err)); // IF ERROR
});  



// add data 

router.route('/add').post((req,res) =>{
    
    const fullname = req.body.fullname;
  
    const email = req.body.email;
  

    const newStudent = new Student({fullname,  email}) // Instantiate the User in user.model

    newStudent.save()  //PROMISE
        .then(student => res.json('New record added!'))  // IF TRUE CHECK
        .catch(err => res.status(400).json('Error: '+ err));  // CATCH THE ERROR 

});


//details

router.route('/:id').get((req,res) =>{
    Student.findById(req.params.id)
        .then(student => res.json(student))
        .catch(err => res.status(400).json('Error: ' + err));


})

//delete

router.route('/delete/:id').delete((req,res) =>{
    Student.findByIdAndDelete(req.params.id)
        .then(student => res.json('Record was deleted.'))
        .catch(err => res.status(400).json('Error: ' + err));
})

//update
router.route('/update/:id').post((req, res) => {
    Student.findById(req.params.id)
        .then(student => {
            student.fullname = req.body.fullname;
           
            student.email = req.body.email;
          

            student.save()
                .then(user => res.json('Record was updated.'))
                .catch(err => res.status(400).json('Error: ' + err));
        })
        .catch(err => res.status(400).json('Error: ' + err));
});




module.exports=router;




